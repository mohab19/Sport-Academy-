<html>
<head>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
</head>
<body style="background:#0B2232">

<h1 style="background: #c31925;color:#fff;padding:50px;margin:15% auto;text-align:center;width:70%;border-radius:10px;">
    Sorry , You Searching For Nothing
</h1>
</body>
</html>