@extends('layouts.master')

@section('style')
    <style>
       .coach
       {
            display:inline-block;
           margin:5px;
           padding:5px;
           border:1px solid #ddd;
       }
        .coach .text
        {
            font-size:16px;
        }
    </style>

@endsection

@section('title')
    {{$place->name}}
@endsection

@section('contents')
    <div id="private">
        <input type="hidden" name="id" value="{{$place->id}}">
    </div>
    <section class="header">
        <div class="container">
            <h5 class="fl-left">Place : {{$place->name}}</h5>
            <h5 class="fl-right"><a href="{{URL::route('schedules')}}">Back To Schedules</a> </h5>
        </div>
    </section>
    <div class="content">
        <div class="container-fluid">
            <div class="box box-lg info">
                <h3 class="title rose">Coaches</h3>
                    <div class="coaches">
                        @foreach($place->coaches_places as $coach_place)
                            <a href="/schedule/place/coach/{{$coach_place->id}}/timetable">
                                <div class="coach">
                                <div class="image text-center">
                                    <img width="120" height="120" src="@if($coach_place->coach->user->picture){{$coach_place->coach->user->picture}}@else  {{ asset('images/Users/default.gif')}}  @endif">
                                </div>
                                <div class="text text-center dark-gray">
                                    {{$coach_place->coach->user->short_name}}
                                </div>
                            </div>
                            </a>
                        @endforeach
                    </div>
            </div>
            <div class="text-center">
                <a href="/schedule/place/{{$place->id}}/fulltimetable"><button class="main-button">Generate FullTimeTable</button></a>
            </div>
        </div>
    </div>

@endsection
@section('script')
    <script src="{{ asset('Ajax/Schedules.js')}}"></script>
@endsection
