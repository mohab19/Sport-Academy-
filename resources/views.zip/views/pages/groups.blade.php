@extends('layouts.dashboard')

@section('style')

    <style>

    </style>
@endsection

@section('title')
    Groups
@endsection

@section('tab')

    @include('forms.groups.add')
    <button class="main-button AddNewsButton AddButton" data-popup="add-group-popup">+</button>
    <table class="table text-center">
        <thead> <!-- main row -->
        <tr class="info">
                <th>
                    Name
                </th>
                <th>
                    Owner
                </th>
                <th>
                    Users
                </th>
            <th>
                Options
            </th>

        </tr>
        </thead> <!-- main row -->
        <tbody>
        @foreach($groups as $group)
            <tr class="danger">
                <td>
                    {{$group->name}}
                </td>
                <td>
                    {{$group->owner->name}}
                </td>
                <td>
                    {{$group->group_users->count()}}
                </td>
                <td>
                    <a href="{{"/group/$group->id/{$group->name}"}}"><i class="fa fa-info"></i></a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table> <!-- table -->
@endsection
@section('script')
    <script>
    </script>
    <script src="{{ asset('Ajax/Groups.js')}}"></script>
@endsection