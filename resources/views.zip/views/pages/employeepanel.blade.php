@extends('layouts.dashboard')

@section('style')

@endsection

@section('title')
    Killing Shot - Employee
    @endsection

    @section('tab')

    @endsection
@section('script')

@endsection
