<!doctype html>
<html>

<head>
    <!-- Css Files -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <style>
        body
        {
            background:#eee;
        }
    </style>
    @yield('style')
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/media.css') }}">
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <meta charset="utf-8">
    <title>
        @yield('title')
    </title>
</head>
<body>
<div class="results"></div>
@yield('contents')
@include('layouts.loading')
<!-- Js Files -->
<script src="{{ asset('js/jquery-3.1.0.min.js')}}"></script>
<script src="{{ asset('js/bootstrap.js')}}"></script>
<script src="{{ asset('js/jquery.nicescroll.min.js')}}"></script>
<!-- DataTables -->
<script src="{{ asset('js/jquery.dataTables.js') }}"></script>
<script src="{{ asset('js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ asset('js/main.js')}}"></script>
<script>
    new WOW().init();
</script>
<script>
    $('.list-view').DataTable({
        "paging": false,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": false,
        "autoWidth": false
    });
</script>
<script>
    $(".dataTables_filter input").removeClass("form-control input-sm").
    appendTo("#Players-Filter,#Coaches-Filter,#Managements-Filter");
    $(".dataTables_length select").removeClass("form-control input-sm").
    appendTo("#Players-Length,#Coaches-Length,#Managements-Length");
    $("div.dataTables_length label , div.dataTables_filter label").remove();
    $("div.filter input").attr('placeholder','Search ...');

    $(".dataTables_paginate").detach().appendTo(".pagination");
</script>
@yield('script')
</body>
</html>