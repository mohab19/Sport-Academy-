 <table class="table">
            <thead>
            <tr class="info">
                <th>Name</th>
                <th>Salary</th>
                <th>Penalty</th>
                <th>Extra</th>
                <th>Net Salary</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            <?php $total = 0; ?>
            @foreach($outcomes as $outcome)
                    <?php $total+=$outcome->value; ?>
                    <tr class="danger">
                        <td>{{$outcome->user->name}}</td>
                        @if($outcome->user->coach->salary)
                        <td>{{$outcome->user->coach->salary}}</td>
                        @else
                            <td>{{$outcome->user->employee->salary}}</td>
                        @endif
                            <td>{{$outcome->value}}</td>
                        <td>{{date('F',strtotime($outcome->date))}} {{date('Y',strtotime($outcome->date))}}</td>
                    </tr>
            @endforeach
            <tr class="info">
                <td>Total</td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{$total}}</td>
                <td></td>
            </tr>
            </tbody>
        </table>