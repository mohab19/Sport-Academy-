 <table class="table">
            <thead>
            <tr class="info">
                <th>Product</th>
                <th>Quantity</th>
                <th>Paid</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            <?php $total = 0; ?>
            @foreach($outcomes as $outcome)
                    <?php $total+=$outcome->value; ?>
                    <tr class="danger">
                        <td>
                            <a href="/product/{{$outcome->product->id}}/{{$outcome->product->name}}"> {{$outcome->product->name}}</a>
                        </td>
                        <td>{{$outcome->quantity}}</td>
                        <td>{{$outcome->value}}</td>
                        <td>{{$outcome->date}}</td>
                    </tr>
            @endforeach
            <tr class="info">
                <td>Total</td>
                <td></td>
                <td>{{$total}}</td>
                <td></td>
            </tr>
            </tbody>
        </table>