 <table class="table">
            <thead>
            <tr class="info">
                <th>Player</th>
                <th>From</th>
                <th>To</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Reciver</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            <?php $total = 0; ?>
            @foreach($incomes as $income)
                    <?php $total+=$income->value; ?>
                    <tr class="danger">
                        <td>
                            <a href="/player/{{$income->player->id}}/{{$income->player->user->name}}"> {{$income->player->user->name}}</a>
                        </td>
                        <td>{{$income->subscription->start}}</td>
                        <td>{{$income->subscription->end}}</td>
                        <td>{{$income->subscription->total}}</td>
                        <td>{{$income->subscription->paid}}</td>
                        <td>{{$income->user->name}}</td>
                        <td>{{$income->date}}</td>
                    </tr>
            @endforeach
            <tr class="info">
                <td>Total</td>
                <td></td>
                <td></td>
                <td></td>
                <td>{{$total}}</td>
                <td></td>
                <td></td>
            </tr>
            </tbody>
        </table>