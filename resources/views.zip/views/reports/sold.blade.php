 <table class="table">
            <thead>
            <tr class="info">
                <th>Product</th>
                <th>Player</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Reciver</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            <?php $total_paid = 0; ?>
            <?php $total_total = 0; ?>
            @foreach($incomes as $income)
                    <?php $total_paid+=$income->value; ?>
                    <?php $total_total+=$income->total; ?>
                    <tr class="danger">
                        <td>
                            <a href="/product/{{$income->product->id}}/{{$income->product->name}}"> {{$income->product->name}}</a>
                        </td>
                        <td>
                            {{$income->user->name}}
                        </td>
                        <td>{{$income->quantity}}</td>
                        <td>{{$income->total}}</td>
                        <td>{{$income->value}}</td>
                        <td>{{$income->user->name}}</td>
                        <td>{{$income->date}}</td>
                    </tr>
            @endforeach
            <tr class="info">
                <td>Total</td>
                <td></td>
                <td></td>
                <td>{{$total_total}}</td>
                <td>{{$total_paid}}</td>
                <td></td>
                <td></td>
            </tr>
            </tbody>
        </table>