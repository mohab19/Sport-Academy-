<div id="view-image-popup" class="popup" style="width: 85%;margin:2.5% auto;left:7.5%;max-height: 500px"> <!-- add-player-popup -->
    <i class="fa fa-close gray" data-toggle="tooltip" data-placement="right" title="Close"></i>
    <div class="popup-content" style="padding-top:1%;padding-bottom: 1%;">
        <div class="col-xs-12 text-center">
            <img src="" width="600" alt="">
        </div>
        <div class="clearfix"></div>
    </div>
</div>