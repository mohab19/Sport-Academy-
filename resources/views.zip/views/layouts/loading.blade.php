<!-- Start Loading -->
<div class="loading">
    <div class="cssload-loader">
        <img src="{{ asset('images/Loading.png')}}"/>
        <img src="{{ asset('images/Loading.png')}}"/>
        <img src="{{ asset('images/Loading.png')}}"/>
        <img src="{{ asset('images/Loading.png')}}"/>
    </div>
</div>
<!-- End Loading -->